package tw.com.UtilsStore.ForFun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForFunApplicationTests {

	@Test
	void contextLoads() {
	}

}
