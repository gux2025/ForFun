package tw.com.UtilsStore.ForFun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForFunApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForFunApplication.class, args);
	}

}
